//
//  IPMQuickstart-Bridging-Header.h
//  IPMQuickstart
//
//  Created by Kevin Whinnery on 11/29/15.
//  Copyright © 2015 Twilio. All rights reserved.
//

#ifndef IPMQuickstart_Bridging_Header_h
#define IPMQuickstart_Bridging_Header_h

#import <TwilioIPMessagingClient/TwilioIPMessagingClient.h>

#endif /* IPMQuickstart_Bridging_Header_h */
